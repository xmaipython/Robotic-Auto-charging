#include <cmath>
#include <ros/ros.h>
#include "geometry_msgs/PoseWithCovarianceStamped.h"
#include "nav_msgs/OccupancyGrid.h"
#include "sensor_msgs/LaserScan.h"
#include "tf2/utils.h"
#include <chrono>

namespace sym::slam {
#define degree2rad (M_PI / 180.0)

class SymRelo {
public:
  SymRelo();
  ~SymRelo() = default;

private:
  void initialPoseReceived(const geometry_msgs::PoseWithCovarianceStampedConstPtr& msg);
  void mapReceived(const nav_msgs::OccupancyGridConstPtr& msg);
  void laserReceived(const sensor_msgs::LaserScanConstPtr& msg);
  auto rangeRelocate(geometry_msgs::PoseWithCovarianceStamped& best_pose) -> std::pair<int, std::string>;

  ros::Publisher initial_pose_pub_;
  ros::Subscriber initial_pose_sub_;
  ros::Subscriber map_sub_;
  ros::Subscriber laser_sub_;

  nav_msgs::OccupancyGrid map_{};
  sensor_msgs::LaserScan laser_{};
  std::vector<std::pair<double, double>> cos_sin_table_{};

  std::atomic_bool on_going_{false};
  std::atomic_bool got_laser_info_{false};
  std::atomic_bool got_map_{false};
};

SymRelo::SymRelo() {
  ros::NodeHandle nh;
  initial_pose_pub_ = nh.advertise<geometry_msgs::PoseWithCovarianceStamped>("/initialpose", 1);
  initial_pose_sub_ = nh.subscribe("/initialpose_ori", 1, &SymRelo::initialPoseReceived, this);
  map_sub_ = nh.subscribe("/map", 1, &SymRelo::mapReceived, this);
  laser_sub_ = nh.subscribe("/scan", 1, &SymRelo::laserReceived, this);
}

void SymRelo::initialPoseReceived(const geometry_msgs::PoseWithCovarianceStampedConstPtr& msg) {
  if (!got_map_ || !got_laser_info_) {
    ROS_WARN("Waiting for map and laser data...");
    return;
  }

  on_going_ = true;
  auto best_pose = *msg;
  ROS_INFO("Original pose: [%.3f, %.3f, %.3f]",
           msg->pose.pose.position.x, msg->pose.pose.position.y, 
           tf2::getYaw(msg->pose.pose.orientation));
  
  auto start_time = std::chrono::steady_clock::now();  
  auto [score, found_region] = rangeRelocate(best_pose);
  auto end_time = std::chrono::steady_clock::now();
  auto duration = std::chrono::duration<double>(end_time - start_time).count();
  
  // 在发布前将位姿旋转 180 度（π 弧度）
  double current_yaw = tf2::getYaw(best_pose.pose.pose.orientation);
  double new_yaw = current_yaw + M_PI;
  tf2::Quaternion q;
  q.setRPY(0, 0, new_yaw);
  best_pose.pose.pose.orientation = tf2::toMsg(q);

  ROS_WARN("[%s] Best pose: [%.3f, %.3f, %.3f] score: %d, search time: %.3f sec",
           found_region.c_str(),
           best_pose.pose.pose.position.x, 
           best_pose.pose.pose.position.y,
           tf2::getYaw(best_pose.pose.pose.orientation), 
           score, 
           duration);
  
  initial_pose_pub_.publish(best_pose);
  on_going_ = false;
}

void SymRelo::mapReceived(const nav_msgs::OccupancyGridConstPtr& msg) {
  if (on_going_) return;
  map_ = *msg;
  got_map_ = true;
  ROS_INFO("Map received. Resolution: %.3f, Size: %dx%d", 
           map_.info.resolution, map_.info.width, map_.info.height);
}

void SymRelo::laserReceived(const sensor_msgs::LaserScanConstPtr& msg) {
  if (on_going_) return;
  
  laser_ = *msg;
  
  if (got_laser_info_) return;
  
  cos_sin_table_.resize(laser_.ranges.size());
  for (size_t i = 0; i < laser_.ranges.size(); ++i) {
    double angle = laser_.angle_min + i * laser_.angle_increment;
    cos_sin_table_[i] = {std::cos(angle), std::sin(angle)};
  }
  
  got_laser_info_ = true;
  ROS_INFO("Laser data ready. Ranges: %lu, Angle: [%.3f, %.3f]", 
           laser_.ranges.size(), laser_.angle_min, laser_.angle_max);
}

auto SymRelo::rangeRelocate(geometry_msgs::PoseWithCovarianceStamped& best_pose) -> std::pair<int, std::string> {
  struct SearchConfig {
    double max_dist;      // 当前级别最大距离边界
    double min_dist;      // 当前级别最小距离边界
    double angle_range;   // 角度搜索范围(弧度)
    double dist_reso;     // 距离分辨率
    double angle_reso;    // 角度分辨率
    int min_score;        // 合格分数阈值
    std::string name;     // 级别名称
  };
  
  // Calculate number of valid laser readings
  int valid_laser_count = 0;
  for (size_t i = 0; i < laser_.ranges.size(); ++i) {
    if (laser_.ranges[i] >= laser_.range_min && laser_.ranges[i] <= laser_.range_max) {
      valid_laser_count++;
    }
  }
  
  int step = 8;
  int dynamic_threshold = static_cast<int>(valid_laser_count / step * 0.83);
  
  // Apply reasonable bounds to the threshold
  dynamic_threshold = std::max(10, dynamic_threshold);  // Minimum threshold of 10
  dynamic_threshold = std::min(50, dynamic_threshold);  // Maximum threshold of 50
  
  ROS_INFO("Dynamic threshold calculated: %d (from %d valid readings, step=%d)", 
            dynamic_threshold, valid_laser_count, step);

  // 定义三级非重复搜索范围
  std::vector<SearchConfig> search_levels = {
    // 核心区域 (0-1m) 高精度
    {0.5, 0.0,  360 * degree2rad, 0.05, 1 * degree2rad, dynamic_threshold, "Core"},
    // 中层区域 (1-2m) 中等精度
    {2.0, 0.5, 360 * degree2rad, 0.06, 2 * degree2rad, dynamic_threshold, "Middle"},
    // 外层区域 (2-10m) 低精度
    {10.0, 2.0, 360 * degree2rad, 0.20, 10 * degree2rad, dynamic_threshold, "Outer"}
  };

  // 地图访问函数
  auto mapValid = [&](double x, double y) -> bool {
    int i = static_cast<int>((x - map_.info.origin.position.x) / map_.info.resolution);
    int j = static_cast<int>((y - map_.info.origin.position.y) / map_.info.resolution);
    return (i >= 0 && j >= 0 && i < map_.info.width && j < map_.info.height);
  };

  auto mapObstacle = [&](double x, double y) -> bool {
    int i = static_cast<int>((x - map_.info.origin.position.x) / map_.info.resolution);
    int j = static_cast<int>((y - map_.info.origin.position.y) / map_.info.resolution);
    int idx = i + j * map_.info.width;
    return (idx >= 0 && idx < map_.data.size()) ? (map_.data[idx] >= 50) : false;
  };

  // 计分函数
  auto calcuScore = [&](double x, double y, double yaw) -> int {
    const double laser2base = -0.26;
    double cos_yaw = std::cos(yaw);
    double sin_yaw = std::sin(yaw);
    
    int score = 0;
    int step = 8;
    
    for (size_t i = 0; i < laser_.ranges.size(); i += step) {
      if (laser_.ranges[i] < laser_.range_min || laser_.ranges[i] > laser_.range_max) continue;
      
      double lx = x + laser2base * cos_yaw;
      double ly = y + laser2base * sin_yaw;
      
      double px = lx + laser_.ranges[i] * (cos_yaw * cos_sin_table_[i].first - sin_yaw * cos_sin_table_[i].second);
      double py = ly + laser_.ranges[i] * (sin_yaw * cos_sin_table_[i].first + cos_yaw * cos_sin_table_[i].second);
      
      if (mapValid(px, py) && mapObstacle(px, py)) score++;
    }
    return score;
  };

  // 初始化最佳位姿
  double best_x = best_pose.pose.pose.position.x;
  double best_y = best_pose.pose.pose.position.y;
  double best_yaw = tf2::getYaw(best_pose.pose.pose.orientation);
  int best_score = calcuScore(best_x, best_y, best_yaw);
  std::string found_region = "Initial";  // 默认区域

  // 多级搜索
  for (const auto& config : search_levels) {
    auto level_start = std::chrono::steady_clock::now();
    int level_best_score = 0;
    double level_best_x = best_x;
    double level_best_y = best_y;
    double level_best_yaw = best_yaw;
    
    ROS_DEBUG("=== Searching %s region (%.1f-%.1fm) ===", 
              config.name.c_str(), config.min_dist, config.max_dist);

    // 搜索角度范围
    for (double yaw = best_yaw - config.angle_range/2; 
         yaw <= best_yaw + config.angle_range/2; 
         yaw += config.angle_reso) {
      
      // 搜索距离范围（环形区域）
      for (double x = best_x - config.max_dist; x <= best_x + config.max_dist; x += config.dist_reso) {
        for (double y = best_y - config.max_dist; y <= best_y + config.max_dist; y += config.dist_reso) {
          double dist = std::hypot(x - best_x, y - best_y);
          if (dist <= config.min_dist || dist > config.max_dist) continue;
          if (!mapValid(x, y)) continue;
          
          int current_score = calcuScore(x, y, yaw);
          if (current_score > level_best_score) {
            level_best_score = current_score;
            level_best_x = x;
            level_best_y = y;
            level_best_yaw = yaw;
          }
        }
      }
    }

    // 更新全局最佳
    if (level_best_score > best_score) {
      best_score = level_best_score;
      best_x = level_best_x;
      best_y = level_best_y;
      best_yaw = level_best_yaw;
      found_region = config.name;  // 记录找到最佳位姿的区域
      
      ROS_DEBUG("New best in %s: score=%d at [%.2f, %.2f, %.2f]", 
                config.name.c_str(), best_score, best_x, best_y, best_yaw);
    }

    // 时间统计
    auto level_time = std::chrono::duration<double>(
      std::chrono::steady_clock::now() - level_start).count();
    ROS_DEBUG("%s search completed in %.3f sec (best=%d)", 
              config.name.c_str(), level_time, level_best_score);

    // 提前终止条件
    if (best_score >= config.min_score) {
      ROS_DEBUG("Early termination at %s (score %d >= %d)", 
                config.name.c_str(), best_score, config.min_score);
      break;
    }
  }

  // 更新最佳位姿
  best_pose.pose.pose.position.x = best_x;
  best_pose.pose.pose.position.y = best_y;
  tf2::Quaternion q;
  q.setRPY(0, 0, best_yaw);
  best_pose.pose.pose.orientation = tf2::toMsg(q);

  return {best_score, found_region};
}

} // namespace sym::slam

int main(int argc, char** argv) {
  ros::init(argc, argv, "sym_relocation");
  sym::slam::SymRelo relocator;
  ros::spin();
  return 0;
}
