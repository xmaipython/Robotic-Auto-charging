#!/usr/bin/env python3

import rospy
import os
from geometry_msgs.msg import PoseWithCovarianceStamped

class LocalizationSaver:
    def __init__(self):
        rospy.init_node('localization_saver', anonymous=True)
        self.pose_sub = rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, self.pose_callback)
        self.current_pose = None
        script_dir = os.path.dirname(os.path.abspath(__file__))
        # 构建文件的绝对路径
        self.file_path = os.path.join(script_dir, '../file/robot_position.txt')
        # 检查文件所在目录是否存在，不存在则创建
        file_dir = os.path.dirname(self.file_path)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        self.i = 0

        # 3.5秒后开始记录坐标（等待坐标发布完成）
        self.start_timer = rospy.Timer(rospy.Duration(3.5), self.start_saving_pose, oneshot=True)

    def pose_callback(self, msg):
        self.current_pose = msg

    def start_saving_pose(self, event):
        # 每秒记录坐标
        self.timer = rospy.Timer(rospy.Duration(1.0), self.save_pose)
        rospy.loginfo("开始记录坐标...")

    def save_pose(self, event):
        if self.current_pose:
            try:
                with open(self.file_path, 'w') as file:  # 'w' mode will clear the file before writing
                    file.write(f"{rospy.get_rostime()} "
                               f"{self.current_pose.pose.pose.position.x} "
                               f"{self.current_pose.pose.pose.position.y} "
                               f"{self.current_pose.pose.pose.position.z} "
                               f"{self.current_pose.pose.pose.orientation.x} "
                               f"{self.current_pose.pose.pose.orientation.y} "
                               f"{self.current_pose.pose.pose.orientation.z} "
                               f"{self.current_pose.pose.pose.orientation.w}\n")
                self.i += 1
                rospy.loginfo(f"记录坐标{self.i}。")
            except Exception as e:
                rospy.logerr(f"保存坐标时出错: {e}")


if __name__ == '__main__':
    LocalizationSaver()
    rospy.spin()