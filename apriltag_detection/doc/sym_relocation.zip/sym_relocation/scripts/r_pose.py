#!/usr/bin/env python3

import rospy
import os
from geometry_msgs.msg import PoseWithCovarianceStamped
import time


def read_last_saved_pose():
    # 获取当前脚本的绝对路径
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # 构建文件的绝对路径
    file_path = os.path.join(script_dir, '../file/robot_position.txt')
    pose_with_covariance = PoseWithCovarianceStamped()
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
            rospy.loginfo(f"File content: {lines}")
            if lines:
                last_line = lines[-1].strip().split()
                # 使用 rospy.Time.now() 获取当前 ROS 时间戳
                pose_with_covariance.header.stamp = rospy.Time.now()
                pose_with_covariance.header.frame_id = 'map'
                pose_with_covariance.pose.pose.position.x = float(last_line[1])
                pose_with_covariance.pose.pose.position.y = float(last_line[2])
                pose_with_covariance.pose.pose.position.z = float(last_line[3])
                pose_with_covariance.pose.pose.orientation.x = float(last_line[4])
                pose_with_covariance.pose.pose.orientation.y = float(last_line[5])
                pose_with_covariance.pose.pose.orientation.z = float(last_line[6])
                pose_with_covariance.pose.pose.orientation.w = float(last_line[7])
                pose_with_covariance.pose.covariance = [0.0] * 36
                # rospy.loginfo(f"PoseWithCovarianceStamped read: {pose_with_covariance}")
            else:
                rospy.logwarn("Pose file is empty")
    except FileNotFoundError:
        rospy.logerr(f"Error: File {file_path} not found.")
    except IndexError:
        rospy.logerr("Error: Incorrect file format.")
    except ValueError:
        rospy.logerr("Error: Unable to convert values to float.")
    except Exception as e:
        rospy.logerr(f"Unexpected error: {e}")
    return pose_with_covariance


if __name__ == '__main__':
    rospy.init_node('r_pose', anonymous=True)
    pose_pub = rospy.Publisher('/initialpose_ori', PoseWithCovarianceStamped, queue_size=10)
    start_time = time.time()  # 获取开始时间
    end_time = 2.2  # 设定2.2秒钟后停止
    rate = rospy.Rate(4)  # 设定发布频率为 4 Hz
    while not rospy.is_shutdown() and (time.time() - start_time) < end_time:
        pose_with_covariance = read_last_saved_pose()
        try:
            pose_pub.publish(pose_with_covariance)
            rospy.loginfo(f"Published PoseWithCovarianceStamped to /initialpose at {time.time()}")
        except Exception as e:
            rospy.logerr(f"Error publishing message: {e}")
        rospy.loginfo(f"Time remaining: {end_time - (time.time() - start_time)} seconds")
        rate.sleep()
    rospy.loginfo(f"Node is shutting down after {end_time} seconds")