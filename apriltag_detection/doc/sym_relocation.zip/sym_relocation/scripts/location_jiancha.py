#!/usr/bin/env python3
# coding=utf-8
#手动发布导航目标点
import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction,MoveBaseGoal
if __name__ == '__main__':
    rospy.init_node('send_goal_node')
    ac =actionlib.SimpleActionClient('move_base',MoveBaseAction)
    ac.wait_for_server()
    goal = MoveBaseGoal()
    goal.target_pose.header.frame_id="map"
    goal.target_pose.pose.position.x =7.247
    goal.target_pose.pose.position.y =10.119
    goal.target_pose.pose.position.z =0
    goal.target_pose.pose.orientation.x=0
    goal.target_pose.pose.orientation.y=0
    goal.target_pose.pose.orientation.z=0.9685
    goal.target_pose.pose.orientation.w=0.2487
    ac.send_goal(goal)
    rospy.loginfo("开始导航！")
    ac.wait_for_result()

    if ac.get_state() == actionlib.GoalStatus.SUCCEEDED:
        rospy.logwarn("导航成功!")
    else:
        rospy.logerr("导航失败...")
